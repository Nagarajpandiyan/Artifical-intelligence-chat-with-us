package main

import (
	"github.com/Harkishen-Singh/Jarvis-personal-assistant/service/utils"
)


func main() {
	// utils.LoggerWarn("starting Jarvis service ...")
	// initiate service
	utils.Server("3000")
}
